Frogatto is copyrighted by Frogatto Team.
http://www.frogatto.com/